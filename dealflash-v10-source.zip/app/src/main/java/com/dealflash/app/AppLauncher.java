package com.dealflash.app;
import android.content.*;import android.net.Uri;import android.os.*;import android.widget.Toast;import java.util.regex.*;
public class AppLauncher{
 static final String COUPANG="com.coupang.mobile";
 public static boolean isInstalled(Context c,String p){try{c.getPackageManager().getPackageInfo(p,0);return true;}catch(Exception e){return false;}}
 public static void openProduct(Context c,String source,String raw){
  if("FALLCENT".equals(source)|| (raw!=null&&raw.contains("fallcent.com/product/"))){resolveFallcent(c,raw);return;}
  String url=ProductUrl.canonical(source,raw);if(url==null){Toast.makeText(c,"상품 링크가 올바르지 않아.",Toast.LENGTH_SHORT).show();return;}openCoupang(c,url);
 }
 static void resolveFallcent(Context c,String u){Toast.makeText(c,"쿠팡 상품으로 연결 중…",Toast.LENGTH_SHORT).show();new Thread(()->{WebFetcher.Result r=WebFetcher.fetch(u);String found="";if(r.body!=null){Matcher m=Pattern.compile("https?://(?:link\\.)?coupang\\.com/[^\\\"'<>\\s]+",Pattern.CASE_INSENSITIVE).matcher(r.body.replace("\\/","/"));if(m.find())found=m.group();}String f=found;new Handler(Looper.getMainLooper()).post(()->{if(!f.isEmpty()){if(f.contains("link.coupang.com")){try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(f));i.setPackage(COUPANG);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);return;}catch(Exception ignored){}}String canon=ProductUrl.canonicalCoupang(f);if(canon!=null){openCoupang(c,canon);return;}}web(c,u);});}).start();}
 static void openCoupang(Context c,String url){if(isInstalled(c,COUPANG)){try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));i.setPackage(COUPANG);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);c.startActivity(i);return;}catch(Exception ignored){}}web(c,url);}
 static void web(Context c,String u){try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(u));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);}catch(Exception e){Toast.makeText(c,"상품 페이지를 열 수 없어.",Toast.LENGTH_SHORT).show();}}
 public static void openUrl(Context c,String u){if(u!=null&&u.contains("fallcent.com/product/")){resolveFallcent(c,u);return;}String s=DealItem.detectSource(u);if("COUPANG".equals(s)){openProduct(c,s,u);return;}web(c,u);}
 public static void warmCoupang(Context c){if(isInstalled(c,COUPANG)){Intent i=c.getPackageManager().getLaunchIntentForPackage(COUPANG);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);return;}}web(c,"https://www.coupang.com/");}
 public static void warmToss(Context c){web(c,"https://toss.im/");}
}
