package com.dealflash.app;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class AutoCatalog {
    public static class Feed {
        public final String source;
        public final String name;
        public final String url;
        public Feed(String source, String name, String url) {
            this.source = source; this.name = name; this.url = url;
        }
    }

    public static List<Feed> build(boolean coupang, boolean toss) {
        ArrayList<Feed> out = new ArrayList<>();
        // Personal V1.0: use only Fallcent's public recommendation page as the fast signal source.
        // This avoids sweeping hundreds of Coupang pages and lets the app react to newly surfaced deals.
        out.add(new Feed("FALLCENT", "폴센트 추천 급락", "https://fallcent.com/product/recommend/?from=gnb"));
        return out;
    }

    private static void addCat(List<Feed> out, String name, String id) {
        // Two pages per category broadens coverage while keeping a full sweep fast enough.
        out.add(new Feed("COUPANG", name + " 1p", "https://www.coupang.com/np/categories/" + id + "?listSize=48&page=1"));
        out.add(new Feed("COUPANG", name + " 2p", "https://www.coupang.com/np/categories/" + id + "?listSize=48&page=2"));
    }
}
