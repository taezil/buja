package com.dealflash.app;
import android.content.*;import android.net.Uri;import android.os.*;import android.widget.Toast;
public class AppLauncher{
 static final String COUPANG="com.coupang.mobile";
 public static boolean isInstalled(Context c,String p){try{c.getPackageManager().getPackageInfo(p,0);return true;}catch(Exception e){return false;}}
 public static void openProduct(Context c,String source,String raw){String url=ProductUrl.canonical(source,raw);if(url==null){Toast.makeText(c,"상품 링크가 올바르지 않아.",Toast.LENGTH_SHORT).show();return;}if("COUPANG".equals(source)&&isInstalled(c,COUPANG)){try{Intent launch=c.getPackageManager().getLaunchIntentForPackage(COUPANG);if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);c.startActivity(launch);}new Handler(Looper.getMainLooper()).postDelayed(()->{try{Intent deep=new Intent(Intent.ACTION_VIEW,Uri.parse(url));deep.setPackage(COUPANG);deep.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);c.startActivity(deep);}catch(Exception e){web(c,url);}},450);return;}catch(Exception ignored){}}web(c,url);}
 static void web(Context c,String u){try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(u));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);}catch(Exception e){Toast.makeText(c,"상품 페이지를 열 수 없어.",Toast.LENGTH_SHORT).show();}}
 public static void openUrl(Context c,String u){String s=DealItem.detectSource(u);String x=ProductUrl.canonical(s,u);if(x!=null&&"COUPANG".equals(s)){openProduct(c,s,x);return;}web(c,u);}
 public static void warmCoupang(Context c){if(isInstalled(c,COUPANG)){Intent i=c.getPackageManager().getLaunchIntentForPackage(COUPANG);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);return;}}web(c,"https://www.coupang.com/");}
 public static void warmToss(Context c){web(c,"https://toss.im/");}
}
