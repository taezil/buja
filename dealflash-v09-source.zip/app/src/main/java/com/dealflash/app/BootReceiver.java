package com.dealflash.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent intent) {
        if (!ScannerPrefs.enabled(c)) return;
        Intent i=new Intent(c,MonitorService.class);
        try {
            if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i); else c.startService(i);
        } catch(Exception ignored){}
    }
}
