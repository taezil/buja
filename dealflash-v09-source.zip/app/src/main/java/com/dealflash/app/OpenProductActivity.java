package com.dealflash.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

/** Notification trampoline: validates the saved product URL, tries the shopping app, then web fallback. */
public class OpenProductActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        String source = getIntent().getStringExtra("source");
        String url = getIntent().getStringExtra("url");
        String safe = ProductUrl.canonical(source, url);
        if (safe == null) {
            Toast.makeText(this, "상품 링크 검증에 실패했어.", Toast.LENGTH_LONG).show();
            finish(); return;
        }
        AppLauncher.openProduct(this, source, safe);
        finish();
    }
}
