package com.dealflash.app;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class AutoCatalog {
    public static class Feed {
        public final String source;
        public final String name;
        public final String url;
        public Feed(String source, String name, String url) {
            this.source = source; this.name = name; this.url = url;
        }
    }

    public static List<Feed> build(boolean coupang, boolean toss) {
        ArrayList<Feed> out = new ArrayList<>();
        if (coupang) {
            // Broad Coupang category pages that expose product cards directly.
            addCat(out, "가전디지털", "178255");
            addCat(out, "식품", "519619");
            addCat(out, "주방용품", "185669");
            addCat(out, "홈인테리어", "184555");
            addCat(out, "생활용품", "115673");
            addCat(out, "반려동물용품", "115674");
            addCat(out, "쿠팡수입/종합", "510691");

            // Search feeds fill gaps where top-level category ids can change.
            String[] keywords = {
                    "노트북", "모니터", "SSD", "스마트폰", "태블릿", "이어폰", "TV", "냉장고",
                    "세탁기", "청소기", "에어컨", "주방가전", "식품", "건강식품", "생활용품", "주방용품",
                    "가구", "침구", "공구", "자동차용품", "스포츠", "캠핑", "완구", "유아동",
                    "반려동물", "뷰티", "화장품", "패션", "신발", "가방", "문구", "게임"
            };
            for (String k : keywords) {
                String q = URLEncoder.encode(k, StandardCharsets.UTF_8);
                out.add(new Feed("COUPANG", "검색·" + k,
                        "https://www.coupang.com/np/search?q=" + q + "&channel=user&listSize=36"));
            }
        }
        if (toss) {
            // Toss Shopping's consumer catalog is app-centric and has no anonymous catalog API.
            // These public entry points are still scanned for exposed product cards/share links.
            out.add(new Feed("TOSS", "토스쇼핑 공개 진입", "https://toss.im/en-us/service/shopping"));
            out.add(new Feed("TOSS", "토스쇼핑 쉐어링크", "https://sharelink.toss.im/"));
        }
        return out;
    }

    private static void addCat(List<Feed> out, String name, String id) {
        // Two pages per category broadens coverage while keeping a full sweep fast enough.
        out.add(new Feed("COUPANG", name + " 1p", "https://www.coupang.com/np/categories/" + id + "?listSize=48&page=1"));
        out.add(new Feed("COUPANG", name + " 2p", "https://www.coupang.com/np/categories/" + id + "?listSize=48&page=2"));
    }
}
