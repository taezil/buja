package com.dealflash.app;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.PowerManager;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MonitorService extends Service {
    public static volatile boolean running=false;
    private final AtomicBoolean loopStarted=new AtomicBoolean(false);
    private volatile boolean stop=false;
    private ExecutorService loopExec;
    private PowerManager.WakeLock wakeLock;
    private BrowserScanner browser;
    private int globalBlockStreak=0;

    @Override public void onCreate(){
        super.onCreate();
        NotificationHelper.ensureChannels(this);
        startForeground(4101,NotificationHelper.monitorNotification(this,"브라우저 스캐너 준비 중"));
        loopExec=Executors.newSingleThreadExecutor();
        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
        wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"DealFlash:BrowserScannerV5");
        browser=new BrowserScanner(this);
        running=true;
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null&&"STOP".equals(intent.getAction())){ScannerPrefs.enabled(this,false);stopSelf();return START_NOT_STICKY;}
        ScannerPrefs.enabled(this,true);
        if(loopStarted.compareAndSet(false,true)) loopExec.submit(this::loop);
        return START_STICKY;
    }

    private void loop(){
        while(!stop&&ScannerPrefs.enabled(this)){
            long roundStart=System.currentTimeMillis();
            List<AutoCatalog.Feed> feeds=AutoCatalog.build(ScannerPrefs.coupang(this),ScannerPrefs.toss(this));
            if(feeds.isEmpty()){
                updateMonitor("플랫폼이 모두 꺼져 있음"); sleep(3000); continue;
            }

            long skipped=ScannerPrefs.cooldownSkips(this);
            FeedChoice choice=chooseFeed(feeds,System.currentTimeMillis());
            if(choice.feed==null){
                skipped+=choice.skipped;
                ScannerPrefs.stats(this,System.currentTimeMillis(),ScannerPrefs.pages(this),ScannerPrefs.products(this),ScannerPrefs.hits(this),
                        ScannerPrefs.rejected(this),ScannerPrefs.errors(this),ScannerPrefs.success(this),skipped,
                        ScannerPrefs.blocked(this),ScannerPrefs.timeouts(this),ScannerPrefs.empty(this),"차단/오류 쿨다운 대기");
                updateMonitor("접근 제한 피해서 쉬는 중 · 약 "+Math.max(1,choice.waitMs/1000)+"초 후 재개");
                sleep(Math.min(60_000L,Math.max(5_000L,choice.waitMs)));
                continue;
            }
            skipped+=choice.skipped;
            AutoCatalog.Feed feed=choice.feed;

            if(wakeLock!=null&&!wakeLock.isHeld()) try{wakeLock.acquire(40_000L);}catch(Exception ignored){}
            Map<String,HistoryStore.H> history=HistoryStore.load(this);
            long pages=ScannerPrefs.pages(this), products=ScannerPrefs.products(this), hits=ScannerPrefs.hits(this);
            long rejected=ScannerPrefs.rejected(this), errors=ScannerPrefs.errors(this), success=ScannerPrefs.success(this);
            long blocked=ScannerPrefs.blocked(this), timeouts=ScannerPrefs.timeouts(this), empty=ScannerPrefs.empty(this);

            BrowserScanner.PageResult p=browser.scanListings(feed.url,feed.source,26_000L);
            pages++;
            String state=p.status==null||p.status.isEmpty()?p.error:p.status;
            String current=feed.name+" · "+state;
            long adaptiveExtra=0L;

            if(p.blocked){
                blocked++;errors++;globalBlockStreak++;
                long until=FeedCooldownStore.onBlocked(this,feed);
                current += " · 이 경로 "+formatRemaining(until-System.currentTimeMillis())+" 쉼";
                adaptiveExtra=globalBlockStreak>=3?60_000L:(globalBlockStreak==2?25_000L:10_000L);
            } else if(p.timeout){
                timeouts++;errors++;globalBlockStreak=Math.max(0,globalBlockStreak-1);
                long until=FeedCooldownStore.onTimeout(this,feed);
                current += " · 이 경로 "+formatRemaining(until-System.currentTimeMillis())+" 쉼";
                adaptiveExtra=8_000L;
            } else if(!p.ok){
                empty++;
                // Toss public entry pages are not guaranteed to expose a catalog, so don't make them
                // look like hard network failures in the main error count.
                if(!"TOSS".equals(feed.source)) errors++;
                globalBlockStreak=Math.max(0,globalBlockStreak-1);
                long until=FeedCooldownStore.onEmpty(this,feed);
                current += " · DOM 재시도 후 "+formatRemaining(until-System.currentTimeMillis())+" 쉼";
            } else {
                success++;globalBlockStreak=0;FeedCooldownStore.onSuccess(this,feed);
                products+=p.items.size();
                ProcessResult pr=processListings(feed,p.items,history);
                hits+=pr.hits; rejected+=pr.rejected;
            }

            HistoryStore.save(this,history);
            long now=System.currentTimeMillis();
            ScannerPrefs.stats(this,now,pages,products,hits,rejected,errors,success,skipped,blocked,timeouts,empty,current);
            updateMonitor("브라우저 감시 · 정상 "+success+"p · "+products+"상품 · 알림 "+hits+" · 차단 "+blocked);

            // Do not add extra background requests while the site is actively rejecting the scanner.
            if(!p.blocked) checkOneManualIfAny();
            if(wakeLock!=null&&wakeLock.isHeld()) try{wakeLock.release();}catch(Exception ignored){}
            long elapsed=System.currentTimeMillis()-roundStart;
            long base=Math.max(10_000L,ScannerPrefs.interval(this)*1000L);
            long wait=Math.max(900L,base-elapsed)+adaptiveExtra;
            sleep(wait);
        }
        stopSelf();
    }

    private FeedChoice chooseFeed(List<AutoCatalog.Feed> feeds,long now){
        FeedChoice out=new FeedChoice();
        int n=feeds.size();
        int start=ScannerPrefs.cursor(this)%n;
        long soonest=Long.MAX_VALUE;
        for(int step=0;step<n;step++){
            int idx=(start+step)%n;
            AutoCatalog.Feed f=feeds.get(idx);
            long remain=FeedCooldownStore.remaining(this,f,now);
            if(remain<=0){
                out.feed=f;out.skipped=step;
                ScannerPrefs.cursor(this,(idx+1)%n);
                return out;
            }
            out.skipped++;
            if(remain<soonest)soonest=remain;
        }
        out.waitMs=soonest==Long.MAX_VALUE?30_000L:soonest;
        ScannerPrefs.cursor(this,(start+1)%n);
        return out;
    }

    private ProcessResult processListings(AutoCatalog.Feed feed,List<PageScanner.Listing> items,Map<String,HistoryStore.H> hist){
        ProcessResult result=new ProcessResult();
        int threshold=ScannerPrefs.threshold(this); long now=System.currentTimeMillis();
        for(PageScanner.Listing x:items){
            String safe=ProductUrl.canonical(feed.source,x.url);
            if(safe==null || ("COUPANG".equals(feed.source)&&!ProductUrl.isStrictCoupang(safe))) { result.rejected++; continue; }
            x.url=safe; x.key=ProductUrl.key(feed.source,safe);
            if(x.key==null||x.key.isEmpty()){result.rejected++;continue;}

            HistoryStore.H h=hist.get(x.key);
            boolean hadHistory=h!=null && h.reference>=5000 && h.lastSeen>0;
            if(h==null){
                h=new HistoryStore.H(); h.key=x.key; h.title=x.title; h.url=x.url; h.source=feed.source;
                h.reference=x.price; h.last=x.price; h.low=x.price; h.firstSeen=now; h.lastSeen=now; h.imageUrl=x.imageUrl; h.rocket=x.rocket; h.declaredDiscountPct=x.declaredDiscountPct;
                hist.put(x.key,h);
            }
            if(x.title!=null&&!x.title.isEmpty())h.title=x.title;
            h.url=x.url;h.source=feed.source;h.lastSeen=now;if(x.imageUrl!=null&&!x.imageUrl.isEmpty())h.imageUrl=x.imageUrl;h.rocket=x.rocket;if(x.declaredDiscountPct>0)h.declaredDiscountPct=x.declaredDiscountPct;

            double histRef=hadHistory?h.reference:0;
            double historicalDrop=histRef>x.price?(1.0-x.price/histRef)*100.0:0;
            double displayedDrop=PageScanner.validPair(x.basePrice,x.price)?(1.0-x.price/x.basePrice)*100.0:0;
            boolean suspicious=(historicalDrop>=threshold)||(displayedDrop>=threshold);

            if(suspicious && x.price>=100){
                VerifyResult vr=verifyBeforeAlert(feed,x,h,hadHistory,threshold);
                if(vr.ok){
                    String sig=x.key+"|"+Math.round(vr.current)+"|"+Math.round(vr.reference);
                    if(!sig.equals(h.lastAlertSig)){
                        h.lastAlertSig=sig; result.hits++;
                        String title=vr.title==null||vr.title.isEmpty()?h.title:vr.title;
                        String body=shortTitle(title)+" · "+money(vr.reference)+"원 → "+money(vr.current)+"원 · 상세페이지 가격 재검증 완료";
                        HotDealStore.put(this,x.key,title,vr.url,feed.source,vr.current,vr.reference,vr.pct);
                        NotificationHelper.alertAuto(this,feed.source,x.key,"🚨 검증된 "+vr.pct+"% 급락 · "+platform(feed.source),body,vr.url);
                    }
                }else result.rejected++;
            }

            h.last=x.price; if(h.low<=0||x.price<h.low)h.low=x.price;
            if(!suspicious && x.price>h.reference) h.reference=x.price;
            hist.put(h.key,h);
        }
        return result;
    }

    private VerifyResult verifyBeforeAlert(AutoCatalog.Feed feed,PageScanner.Listing x,HistoryStore.H h,boolean hadHistory,int threshold){
        String safe=ProductUrl.canonical(feed.source,x.url);
        if(safe==null) return VerifyResult.no();
        BrowserScanner.DetailResult d=browser.scanDetail(safe,feed.source,x.price,x.basePrice,22_000L);
        if(!d.ok||d.blocked||d.timeout||d.current<=0||!d.currentMatchedExpected) return VerifyResult.no();

        double ref=0;
        if(hadHistory && h.reference>d.current) ref=h.reference;
        if(PageScanner.validPair(d.base,d.current)){
            double pct=(1.0-d.current/d.base)*100.0;
            if(pct>=threshold) ref=Math.max(ref,d.base);
        }
        if(ref<5000||ref<=d.current) return VerifyResult.no();
        double drop=(1.0-d.current/ref)*100.0;
        if(drop+0.01<threshold||drop>95.0) return VerifyResult.no();
        String verifiedUrl=ProductUrl.canonical(feed.source,d.url);
        if(verifiedUrl==null) verifiedUrl=safe;
        if("COUPANG".equals(feed.source)&&!ProductUrl.isStrictCoupang(verifiedUrl)) return VerifyResult.no();
        // Keep the exact variant identity. A different item/vendorItem must never validate another option.
        if(!ProductUrl.key(feed.source,safe).equals(ProductUrl.key(feed.source,verifiedUrl))) return VerifyResult.no();
        return VerifyResult.yes(ref,d.current,(int)Math.round(drop),d.title,verifiedUrl);
    }

    private void checkOneManualIfAny(){
        List<DealItem> deals=DealStore.load(this); if(deals.isEmpty())return;
        int idx=(int)(ScannerPrefs.pages(this)%deals.size()); DealItem d=deals.get(idx);
        if(!d.enabled)return;
        String safe=ProductUrl.canonical(d.source,d.url);
        d.lastCheckedAt=System.currentTimeMillis();
        if(safe==null){d.lastError="상품 링크 검증 실패";DealStore.upsert(this,d);return;}
        BrowserScanner.DetailResult r=browser.scanDetail(safe,d.source,d.lastPrice,0,20_000L);
        if(!r.ok){d.lastError=r.error.isEmpty()?"상세페이지 읽기 실패":r.error;DealStore.upsert(this,d);return;}
        double price=r.current;
        d.url=ProductUrl.canonical(d.source,r.url)!=null?ProductUrl.canonical(d.source,r.url):safe;
        d.lastPrice=price;if(d.baselinePrice<=0)d.baselinePrice=price;if(d.minPrice<=0||price<d.minPrice)d.minPrice=price;
        double drop=d.baselinePrice>0?(1-price/d.baselinePrice)*100:0;d.lastError="정상 · "+money(price)+"원 · "+String.format(Locale.KOREA,"%.1f",drop)+"%↓";
        if(drop>=d.thresholdPct){String sig=Math.round(price)+"|"+d.url;if(!sig.equals(d.lastHitSignature)){d.lastHitSignature=sig;NotificationHelper.alert(this,d,"🚨 "+Math.round(drop)+"% 급락 · "+d.title,money(d.baselinePrice)+"원 → "+money(price)+"원",d.url);}}
        DealStore.upsert(this,d);
    }

    private static class FeedChoice{AutoCatalog.Feed feed;long waitMs;long skipped;}
    private static class ProcessResult{long hits;long rejected;}
    private static class VerifyResult{
        boolean ok; double reference,current; int pct; String title,url;
        static VerifyResult no(){return new VerifyResult();}
        static VerifyResult yes(double r,double c,int p,String t,String u){VerifyResult v=new VerifyResult();v.ok=true;v.reference=r;v.current=c;v.pct=p;v.title=t;v.url=u;return v;}
    }

    private void updateMonitor(String text){NotificationManager nm=getSystemService(NotificationManager.class);nm.notify(4101,NotificationHelper.monitorNotification(this,text));}
    private void sleep(long ms){try{Thread.sleep(ms);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
    private String money(double d){return NumberFormat.getIntegerInstance(Locale.KOREA).format(Math.round(d));}
    private String platform(String s){return "COUPANG".equals(s)?"쿠팡":"TOSS".equals(s)?"토스쇼핑":"웹";}
    private String shortTitle(String s){if(s==null||s.isEmpty())return"상품";return s.length()>45?s.substring(0,45)+"…":s;}
    private String formatRemaining(long ms){long m=Math.max(1L,(ms+59_999L)/60_000L);return m+"분";}

    @Override public void onDestroy(){stop=true;running=false;if(loopExec!=null)loopExec.shutdownNow();if(browser!=null)browser.destroy();if(wakeLock!=null&&wakeLock.isHeld())try{wakeLock.release();}catch(Exception ignored){}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
