package com.dealflash.app;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Per-feed backoff. This does not try to bypass access controls; it does the opposite:
 * when a site says no, the feed is rested so the scanner does not hammer the same URL.
 */
public final class FeedCooldownStore {
    private static final String PREF = "dealflash_feed_cooldown_v5";
    private FeedCooldownStore() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    private static String id(AutoCatalog.Feed f) {
        return Integer.toHexString((f.source + "|" + f.url).hashCode());
    }

    private static String k(AutoCatalog.Feed f, String suffix) { return id(f) + "_" + suffix; }

    public static long until(Context c, AutoCatalog.Feed f) {
        return p(c).getLong(k(f, "until"), 0L);
    }

    public static int strikes(Context c, AutoCatalog.Feed f) {
        return p(c).getInt(k(f, "strikes"), 0);
    }

    public static long remaining(Context c, AutoCatalog.Feed f, long now) {
        return Math.max(0L, until(c, f) - now);
    }

    public static long onBlocked(Context c, AutoCatalog.Feed f) {
        int s = Math.min(4, strikes(c, f) + 1);
        long minutes = 8L * (1L << Math.max(0, s - 1)); // 8, 16, 32, 64 min
        minutes = Math.min(60L, minutes);
        long until = System.currentTimeMillis() + minutes * 60_000L;
        p(c).edit().putInt(k(f, "strikes"), s).putLong(k(f, "until"), until).apply();
        return until;
    }

    public static long onTimeout(Context c, AutoCatalog.Feed f) {
        int s = Math.min(3, strikes(c, f) + 1);
        long minutes = Math.min(12L, 2L * s); // 2, 4, 6 min
        long until = System.currentTimeMillis() + minutes * 60_000L;
        p(c).edit().putInt(k(f, "strikes"), s).putLong(k(f, "until"), until).apply();
        return until;
    }

    public static long onEmpty(Context c, AutoCatalog.Feed f) {
        int s = Math.min(2, strikes(c, f) + 1);
        long minutes = "TOSS".equals(f.source) ? 20L : (3L + 2L * s); // Toss public pages are often non-catalog pages
        long until = System.currentTimeMillis() + minutes * 60_000L;
        p(c).edit().putInt(k(f, "strikes"), s).putLong(k(f, "until"), until).apply();
        return until;
    }

    public static void onSuccess(Context c, AutoCatalog.Feed f) {
        p(c).edit().remove(k(f, "until")).remove(k(f, "strikes")).apply();
    }

    public static void clear(Context c) { p(c).edit().clear().apply(); }
}
