package com.dealflash.app;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class WebFetcher {
    public static Result fetch(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(true);
            c.setConnectTimeout(4500);
            c.setReadTimeout(5000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36");
            c.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en;q=0.6");
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8");
            c.setRequestProperty("Cache-Control", "no-cache");
            c.setRequestProperty("Pragma", "no-cache");
            c.setRequestProperty("Referer", url.contains("coupang.com") ? "https://www.coupang.com/" : "https://toss.im/");
            c.setRequestProperty("Sec-Fetch-Dest", "document");
            c.setRequestProperty("Sec-Fetch-Mode", "navigate");
            c.setRequestProperty("Sec-Fetch-Site", "same-origin");
            c.setRequestProperty("Upgrade-Insecure-Requests", "1");
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream();
            if (in == null) return new Result(code, "", c.getURL().toString());
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            int total = 0;
            while ((line = r.readLine()) != null && total < 3_000_000) {
                sb.append(line).append('\n'); total += line.length();
            }
            return new Result(code, sb.toString(), c.getURL().toString());
        } catch (Exception e) {
            return new Result(-1, "", url, e.getClass().getSimpleName() + ": " + e.getMessage());
        } finally {
            if (c != null) c.disconnect();
        }
    }

    public static class Result {
        public final int code; public final String body; public final String finalUrl; public final String error;
        public Result(int code, String body, String finalUrl) { this(code, body, finalUrl, ""); }
        public Result(int code, String body, String finalUrl, String error) {
            this.code = code; this.body = body; this.finalUrl = finalUrl; this.error = error == null ? "" : error;
        }
    }
}
