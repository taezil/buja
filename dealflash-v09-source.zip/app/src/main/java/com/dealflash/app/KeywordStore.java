package com.dealflash.app;
import android.content.Context;import org.json.JSONArray;import java.util.*;
public class KeywordStore{
 private static final String P="dealflash_keywords_v6",K="words";
 public static List<String> load(Context c){ArrayList<String> r=new ArrayList<>();try{JSONArray a=new JSONArray(c.getSharedPreferences(P,0).getString(K,"[]"));for(int i=0;i<a.length();i++)r.add(a.getString(i));}catch(Exception ignored){}return r;}
 public static void add(Context c,String s){s=s==null?"":s.trim();if(s.isEmpty())return;List<String>a=load(c);for(String x:a)if(x.equalsIgnoreCase(s))return;a.add(s);save(c,a);}
 public static void remove(Context c,String s){List<String>a=load(c);a.removeIf(x->x.equals(s));save(c,a);}
 private static void save(Context c,List<String>a){JSONArray j=new JSONArray();for(String s:a)j.put(s);c.getSharedPreferences(P,0).edit().putString(K,j.toString()).apply();}
}
