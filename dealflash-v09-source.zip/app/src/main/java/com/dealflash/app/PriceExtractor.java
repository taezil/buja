package com.dealflash.app;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Product-detail price extraction used for second-stage verification before an alert. */
public class PriceExtractor {
    private static final String NUM = "([0-9][0-9,]{2,})";

    private static final Pattern[] CURRENT = new Pattern[] {
            Pattern.compile("(?i)property=[\\\"']product:price:amount[\\\"'][^>]*content=[\\\"']" + NUM + "[\\\"']"),
            Pattern.compile("(?i)itemprop=[\\\"']price[\\\"'][^>]*content=[\\\"']" + NUM + "[\\\"']"),
            Pattern.compile("(?i)\\\"(?:finalPrice|salePrice|salesPrice|discountPrice|totalPrice|sellingPrice)\\\"\\s*:\\s*\\\"?" + NUM),
            Pattern.compile("(?is)class=[\\\"'][^\\\"']*(?:total-price|sale-price|sales-price|price-value|discount-price)[^\\\"']*[\\\"'][^>]*>\\s*(?:<[^>]+>\\s*)*" + NUM)
    };
    private static final Pattern[] BASE = new Pattern[] {
            Pattern.compile("(?i)\\\"(?:basePrice|originalPrice|regularPrice|listPrice|retailPrice)\\\"\\s*:\\s*\\\"?" + NUM),
            Pattern.compile("(?is)class=[\\\"'][^\\\"']*(?:base-price|original-price|regular-price|list-price)[^\\\"']*[\\\"'][^>]*>\\s*(?:<[^>]+>\\s*)*" + NUM)
    };
    private static final Pattern OG_TITLE = Pattern.compile("(?is)<meta[^>]+(?:property|name)=[\\\"'](?:og:title|title)[\\\"'][^>]+content=[\\\"']([^\\\"']+)[\\\"']");
    private static final Pattern TITLE = Pattern.compile("(?is)<title[^>]*>(.*?)</title>");

    public static class ProductSnapshot {
        public double currentPrice;
        public double basePrice;
        public String title = "";
        public boolean currentMatchedExpected;
    }

    public static double extractPrice(String html) {
        ProductSnapshot s = extractProductSnapshot(html, 0, 0);
        return s.currentPrice;
    }

    public static ProductSnapshot extractProductSnapshot(String html, double expectedCurrent, double expectedBase) {
        ProductSnapshot out = new ProductSnapshot();
        if (html == null || html.isEmpty()) return out;
        List<Double> currents = collect(html, CURRENT, 40);
        List<Double> bases = collect(html, BASE, 40);
        out.currentPrice = chooseClosest(currents, expectedCurrent);
        if (expectedCurrent > 0 && out.currentPrice > 0) {
            double tol = Math.max(500.0, expectedCurrent * 0.06);
            out.currentMatchedExpected = Math.abs(out.currentPrice - expectedCurrent) <= tol;
        } else out.currentMatchedExpected = out.currentPrice > 0;

        double targetBase = expectedBase > 0 ? expectedBase : out.currentPrice;
        out.basePrice = chooseBase(bases, out.currentPrice, targetBase);

        Matcher m = OG_TITLE.matcher(html);
        if (m.find()) out.title = clean(m.group(1));
        else {
            m = TITLE.matcher(html);
            if (m.find()) out.title = clean(strip(m.group(1)));
        }
        return out;
    }

    /** First-sighting discount is trusted only when detail HTML contains a real original/current pair. */
    public static boolean verifiedPair(ProductSnapshot s, int threshold) {
        if (s == null || !PageScanner.validPair(s.basePrice, s.currentPrice)) return false;
        double pct = (1.0 - s.currentPrice / s.basePrice) * 100.0;
        return pct >= threshold;
    }

    private static List<Double> collect(String html, Pattern[] ps, int max) {
        ArrayList<Double> list = new ArrayList<>();
        for (Pattern p : ps) {
            Matcher m = p.matcher(html);
            while (m.find() && list.size() < max) {
                double v = toPrice(m.group(1));
                if (valid(v) && !containsNear(list, v)) list.add(v);
            }
        }
        return list;
    }

    private static boolean containsNear(List<Double> list, double v) {
        for (double x : list) if (Math.abs(x - v) < 0.5) return true;
        return false;
    }

    private static double chooseClosest(List<Double> list, double expected) {
        if (list.isEmpty()) return 0;
        if (expected <= 0) return list.get(0);
        double best = list.get(0), d = Math.abs(best - expected);
        for (double v : list) {
            double nd = Math.abs(v - expected);
            if (nd < d) { best = v; d = nd; }
        }
        return best;
    }

    private static double chooseBase(List<Double> list, double current, double expectedBase) {
        double best = 0, bestScore = Double.MAX_VALUE;
        for (double v : list) {
            if (current <= 0 || v <= current) continue;
            double pct = (1.0 - current / v) * 100.0;
            if (pct < 1 || pct > 95) continue;
            double score = expectedBase > current ? Math.abs(v - expectedBase) : v - current;
            if (score < bestScore) { best = v; bestScore = score; }
        }
        return best;
    }

    private static String strip(String s) { return s == null ? "" : s.replaceAll("(?is)<[^>]+>", " ").replaceAll("\\s+", " ").trim(); }
    private static String clean(String s) {
        if (s == null) return "";
        return s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replaceAll("\\s+", " ").trim();
    }
    private static double toPrice(String s) { try { return Double.parseDouble(s.replace(",", "")); } catch(Exception e){ return 0; } }
    private static boolean valid(double v) { return v >= 100 && v <= 1_000_000_000L; }
}
