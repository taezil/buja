package com.dealflash.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Browser-backed scanner. It intentionally behaves like a normal Android WebView and does not
 * attempt to bypass CAPTCHAs or access controls. When Coupang serves a challenge/access-denied
 * page, that is reported as a diagnostic instead of being treated as a product page.
 */
public final class BrowserScanner {
    public static final class PageResult {
        public final List<PageScanner.Listing> items = new ArrayList<>();
        public String finalUrl = "";
        public String title = "";
        public String status = "";
        public String error = "";
        public int productLinks = 0;
        public boolean blocked = false;
        public boolean timeout = false;
        public boolean ok = false;
    }

    public static final class DetailResult {
        public String url = "";
        public String title = "";
        public String error = "";
        public boolean blocked = false;
        public boolean timeout = false;
        public boolean ok = false;
        public double current = 0;
        public double base = 0;
        public boolean currentMatchedExpected = false;
    }

    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final CountDownLatch initLatch = new CountDownLatch(1);
    private final AtomicLong tokenCounter = new AtomicLong();
    private WebView webView;
    private volatile Session current;

    private static final class Session {
        long token;
        boolean detail;
        String source;
        String requestedUrl;
        double expectedCurrent;
        double expectedBase;
        final CountDownLatch done = new CountDownLatch(1);
        PageResult page;
        DetailResult detailResult;
        boolean finished;
        int httpStatus;
        String receivedError = "";
        int extractAttempts = 0;
    }

    public BrowserScanner(Context c) {
        context = c.getApplicationContext();
        main.post(this::createWebView);
        try { initLatch.await(6, TimeUnit.SECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void createWebView() {
        try {
            webView = new WebView(context);
            WebSettings s = webView.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setLoadsImagesAutomatically(false);
            s.setBlockNetworkImage(true);
            s.setJavaScriptCanOpenWindowsAutomatically(false);
            s.setSupportMultipleWindows(false);
            s.setUseWideViewPort(true);
            s.setLoadWithOverviewMode(true);
            s.setCacheMode(WebSettings.LOAD_DEFAULT);
            if (android.os.Build.VERSION.SDK_INT >= 23) s.setOffscreenPreRaster(true);
            CookieManager cm = CookieManager.getInstance();
            cm.setAcceptCookie(true);
            try { cm.setAcceptThirdPartyCookies(webView, true); } catch (Throwable ignored) {}
            webView.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    try { CookieManager.getInstance().flush(); } catch (Throwable ignored) {}
                    Session s = current;
                    if (s == null || s.finished) return;
                    long token = s.token;
                    // Give dynamic product cards time to render, then scroll twice to trigger lazy DOM work.
                    main.postDelayed(() -> {
                        Session now = current;
                        if (now == null || now.finished || now.token != token) return;
                        try { view.evaluateJavascript("window.scrollTo(0, Math.min(document.body.scrollHeight, 1400));", null); } catch (Throwable ignored) {}
                        main.postDelayed(() -> {
                            Session now2 = current;
                            if (now2 == null || now2.finished || now2.token != token) return;
                            try { view.evaluateJavascript("window.scrollTo(0, Math.min(document.body.scrollHeight, 3200));", null); } catch (Throwable ignored) {}
                            main.postDelayed(() -> extract(view, token), 850L);
                        }, 700L);
                    }, 900L);
                }

                @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    if (request != null && request.isForMainFrame()) {
                        Session s = current;
                        if (s != null && !s.finished) s.receivedError = "WEB " + error.getErrorCode() + " " + String.valueOf(error.getDescription());
                    }
                }

                @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                    if (request != null && request.isForMainFrame()) {
                        Session s = current;
                        if (s != null && !s.finished && errorResponse != null) s.httpStatus = errorResponse.getStatusCode();
                    }
                }
            });
            // A non-attached WebView can still execute JS. Give it a realistic viewport for lazy layouts.
            int w = 1080, h = 2400;
            webView.measure(android.view.View.MeasureSpec.makeMeasureSpec(w, android.view.View.MeasureSpec.EXACTLY),
                    android.view.View.MeasureSpec.makeMeasureSpec(h, android.view.View.MeasureSpec.EXACTLY));
            webView.layout(0, 0, w, h);
        } catch (Throwable ignored) {
            webView = null;
        } finally {
            initLatch.countDown();
        }
    }

    public synchronized PageResult scanListings(String url, String source, long timeoutMs) {
        PageResult out = new PageResult();
        if (webView == null) { out.error = "WebView 초기화 실패"; return out; }
        Session s = new Session();
        s.token = tokenCounter.incrementAndGet();
        s.detail = false;
        s.source = source;
        s.requestedUrl = url;
        s.page = out;
        current = s;
        main.post(() -> startLoad(s));
        waitFor(s, timeoutMs);
        if (!s.finished) {
            out.timeout = true; out.error = "브라우저 로딩 시간초과"; finishSession(s);
        }
        return out;
    }

    public synchronized DetailResult scanDetail(String url, String source, double expectedCurrent, double expectedBase, long timeoutMs) {
        DetailResult out = new DetailResult();
        if (webView == null) { out.error = "WebView 초기화 실패"; return out; }
        Session s = new Session();
        s.token = tokenCounter.incrementAndGet();
        s.detail = true;
        s.source = source;
        s.requestedUrl = url;
        s.expectedCurrent = expectedCurrent;
        s.expectedBase = expectedBase;
        s.detailResult = out;
        current = s;
        main.post(() -> startLoad(s));
        waitFor(s, timeoutMs);
        if (!s.finished) {
            out.timeout = true; out.error = "상세페이지 로딩 시간초과"; finishSession(s);
        }
        return out;
    }

    private void startLoad(Session s) {
        if (webView == null || current != s || s.finished) { finishSession(s); return; }
        try {
            webView.stopLoading();
            webView.loadUrl(s.requestedUrl);
        } catch (Throwable t) {
            if (s.detail) s.detailResult.error = "브라우저 열기 실패";
            else s.page.error = "브라우저 열기 실패";
            finishSession(s);
        }
    }

    private void waitFor(Session s, long timeoutMs) {
        try { s.done.await(Math.max(6000L, timeoutMs), TimeUnit.MILLISECONDS); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private void extract(WebView view, long token) {
        Session s = current;
        if (s == null || s.finished || s.token != token) return;
        String script = s.detail ? detailScript() : listingScript();
        try {
            s.extractAttempts++;
            view.evaluateJavascript(script, value -> {
                Session now = current;
                if (now == null || now.finished || now.token != token) return;
                if (now.detail) {
                    parseDetail(now, value);
                    finishSession(now);
                } else {
                    parseListing(now, value);
                    // Dynamic listing prices sometimes appear after product links. Re-read the same
                    // already-loaded DOM once before declaring it empty; no extra HTTP navigation.
                    if (!now.page.ok && !now.page.blocked && now.extractAttempts < 2) {
                        main.postDelayed(() -> {
                            Session again = current;
                            if (again == null || again.finished || again.token != token) return;
                            try { view.evaluateJavascript("window.scrollTo(0, Math.min(document.body.scrollHeight, 5200));", null); } catch (Throwable ignored) {}
                            main.postDelayed(() -> extract(view, token), 900L);
                        }, 1200L);
                    } else finishSession(now);
                }
            });
        } catch (Throwable t) {
            if (s.detail) s.detailResult.error = "DOM 읽기 실패";
            else s.page.error = "DOM 읽기 실패";
            finishSession(s);
        }
    }

    private void parseListing(Session s, String raw) {
        PageResult out = s.page;
        out.finalUrl = safeUrl();
        if (s.httpStatus >= 400) out.error = "HTTP " + s.httpStatus;
        if (!s.receivedError.isEmpty()) out.error = s.receivedError;
        try {
            JSONObject root = new JSONObject(decodeJsString(raw));
            out.finalUrl = root.optString("url", out.finalUrl);
            out.title = root.optString("title", "");
            out.productLinks = root.optInt("links", 0);
            out.blocked = root.optBoolean("blocked", false);
            String why = root.optString("blockReason", "");
            if (out.blocked) {
                out.error = why.isEmpty() ? "접근 제한/캡차" : why;
                out.status = out.error;
                return;
            }
            JSONArray items = root.optJSONArray("items");
            if (items != null) {
                for (int i = 0; i < items.length() && out.items.size() < 260; i++) {
                    JSONObject o = items.optJSONObject(i); if (o == null) continue;
                    String href = o.optString("url", "");
                    if ("COUPANG".equals(s.source)) href = ProductUrl.canonicalCoupang(href);
                    else href = ProductUrl.canonical(s.source, href);
                    if (href == null) continue;
                    double price = o.optDouble("price", 0);
                    if (price < 100 || price > 1_000_000_000L) continue;
                    PageScanner.Listing x = new PageScanner.Listing();
                    x.url = href;
                    x.key = ProductUrl.key(s.source, href);
                    x.title = cleanTitle(o.optString("title", "상품"));
                    x.price = price;
                    x.basePrice = o.optDouble("base", 0);
                    if (!PageScanner.validPair(x.basePrice, x.price)) x.basePrice = 0;
                    x.declaredDiscountPct = o.optInt("discount", 0);
                    x.imageUrl = o.optString("image", "");
                    x.rocket = o.optBoolean("rocket", false);
                    out.items.add(x);
                }
            }
            if (!out.items.isEmpty()) {
                out.ok = true;
                out.status = "정상 " + out.items.size() + "상품";
            } else if (out.productLinks > 0) {
                out.error = "상품 링크 " + out.productLinks + "개 · 가격 DOM 없음";
                out.status = out.error;
            } else {
                out.error = out.error.isEmpty() ? "상품 DOM 없음" : out.error;
                out.status = out.error;
            }
        } catch (Exception e) {
            out.error = "DOM JSON 파싱 실패";
            out.status = out.error;
        }
    }

    private void parseDetail(Session s, String raw) {
        DetailResult out = s.detailResult;
        out.url = safeUrl();
        if (s.httpStatus >= 400) out.error = "HTTP " + s.httpStatus;
        if (!s.receivedError.isEmpty()) out.error = s.receivedError;
        try {
            JSONObject root = new JSONObject(decodeJsString(raw));
            out.url = root.optString("url", out.url);
            out.title = cleanTitle(root.optString("title", ""));
            out.blocked = root.optBoolean("blocked", false);
            if (out.blocked) { out.error = root.optString("blockReason", "접근 제한/캡차"); return; }
            List<Double> currents = toList(root.optJSONArray("current"));
            List<Double> bases = toList(root.optJSONArray("base"));
            out.current = chooseClosest(currents, s.expectedCurrent);
            if (s.expectedCurrent > 0 && out.current > 0) {
                double tol = Math.max(300.0, s.expectedCurrent * 0.02);
                out.currentMatchedExpected = Math.abs(out.current - s.expectedCurrent) <= tol;
            } else out.currentMatchedExpected = out.current > 0;
            out.base = chooseBase(bases, out.current, s.expectedBase);
            out.ok = out.current > 0;
            if (!out.ok && out.error.isEmpty()) out.error = "상세가격 DOM 없음";
        } catch (Exception e) {
            out.error = "상세 DOM JSON 파싱 실패";
        }
    }

    private static List<Double> toList(JSONArray a) {
        ArrayList<Double> out = new ArrayList<>();
        if (a == null) return out;
        for (int i = 0; i < a.length() && out.size() < 40; i++) {
            double v = a.optDouble(i, 0);
            if (v >= 100 && v <= 1_000_000_000L) {
                boolean dup = false; for (double x : out) if (Math.abs(x-v) < 0.5) { dup = true; break; }
                if (!dup) out.add(v);
            }
        }
        return out;
    }

    private static double chooseClosest(List<Double> list, double expected) {
        if (list.isEmpty()) return 0;
        if (expected <= 0) return list.get(0);
        double best = list.get(0), d = Math.abs(best - expected);
        for (double v : list) { double nd = Math.abs(v - expected); if (nd < d) { best = v; d = nd; } }
        return best;
    }

    private static double chooseBase(List<Double> list, double current, double expectedBase) {
        double best = 0, bestScore = Double.MAX_VALUE;
        for (double v : list) {
            if (current <= 0 || v <= current) continue;
            double pct = (1.0 - current / v) * 100.0;
            if (pct < 1 || pct > 95) continue;
            double score = expectedBase > current ? Math.abs(v - expectedBase) : (v-current);
            if (score < bestScore) { best = v; bestScore = score; }
        }
        return best;
    }

    private String safeUrl() {
        try { return webView == null ? "" : String.valueOf(webView.getUrl()); } catch (Throwable t) { return ""; }
    }

    private void finishSession(Session s) {
        if (s == null || s.finished) return;
        s.finished = true;
        s.done.countDown();
    }

    private static String decodeJsString(String raw) throws Exception {
        if (raw == null || "null".equals(raw)) return "{}";
        // evaluateJavascript returns a JSON string literal around our JSON.stringify result.
        JSONArray box = new JSONArray("[" + raw + "]");
        return box.getString(0);
    }

    private static String cleanTitle(String s) {
        if (s == null) return "";
        s = s.replaceAll("\\s+", " ").trim();
        return s.length() > 120 ? s.substring(0, 120) : s;
    }

    private static String listingScript() {
        return "(function(){"+
                "function n(t){if(!t)return 0;var m=String(t).replace(/\\u00a0/g,' ').match(/([0-9][0-9,]{2,})/);if(!m)return 0;var v=parseInt(m[1].replace(/,/g,''),10);return (v>=100&&v<=1000000000)?v:0;}"+
                "function val(box,sels){for(var i=0;i<sels.length;i++){var e=box.querySelector(sels[i]);if(e){var v=n(e.getAttribute('content')||e.textContent);if(v)return v;}}return 0;}"+
                "function txt(box,sels){for(var i=0;i<sels.length;i++){var e=box.querySelector(sels[i]);if(e&&e.textContent&&e.textContent.trim())return e.textContent.trim();}return '';}"+
                "function box(a){var x=a;for(var i=0;i<7&&x;i++,x=x.parentElement){var c=(x.className||'').toString().toLowerCase();if(x.tagName==='LI'||c.indexOf('search-product')>=0||c.indexOf('product-unit')>=0||c.indexOf('product-card')>=0||c.indexOf('baby-product')>=0)return x;}return a.parentElement||a;}"+
                "var bt=(document.body&&document.body.innerText?document.body.innerText:'').toLowerCase();"+
                "var blocked=(bt.indexOf('access denied')>=0||bt.indexOf('captcha')>=0||bt.indexOf('자동입력')>=0||bt.indexOf('로봇이 아닙니다')>=0||bt.indexOf('비정상적인 접근')>=0);"+
                "var reason=bt.indexOf('captcha')>=0?'CAPTCHA':(bt.indexOf('access denied')>=0?'Access Denied':(bt.indexOf('비정상적인 접근')>=0?'비정상 접근 차단':(bt.indexOf('자동입력')>=0?'자동입력 확인':'')));"+
                "var as=Array.prototype.slice.call(document.querySelectorAll('a[href*=\"/vp/products/\"],a[href*=\"/np/products/\"],a[href*=\"/vm/products/\"]'));var out=[],seen={};"+
                "for(var j=0;j<as.length&&out.length<260;j++){var a=as[j],href=a.href||a.getAttribute('href')||'';var mm=href.match(/\\/(?:vp|np|vm)\\/products\\/(\\d+)/i);if(!mm||seen[mm[1]])continue;var b=box(a);"+
                "var price=val(b,['strong.price-value','.price-value','[class*=\"price-value\"]','[class*=\"sale-price\"]','[class*=\"sales-price\"]','[class*=\"discount-price\"]','[class*=\"final-price\"]']);"+
                "if(!price)continue;var base=val(b,['.base-price','[class*=\"base-price\"]','[class*=\"original-price\"]','[class*=\"regular-price\"]','[class*=\"list-price\"]','del','s']);"+
                "var title=txt(b,['.name','[class*=\"product-name\"]','[class*=\"product-title\"]','[class*=\"name\"]']);if(!title)title=(a.getAttribute('title')||a.textContent||'').trim();"+
                "var disc=0;var de=b.querySelector('[class*=\"discount-percentage\"],[class*=\"discount-rate\"],[class*=\"discount\"]');if(de){var dm=(de.textContent||'').match(/([0-9]{1,3})\\s*%/);if(dm)disc=parseInt(dm[1],10)||0;}"+
                "var im=b.querySelector('img');var image=im?(im.currentSrc||im.src||im.getAttribute('data-img-src')||im.getAttribute('data-src')||''):'';if(image&&image.indexOf('//')===0)image='https:'+image;var rocket=/로켓배송|로켓와우|rocket/i.test(b.innerText||'');"+
                "seen[mm[1]]=1;out.push({url:href,title:title,price:price,base:base,discount:disc,image:image,rocket:rocket});}"+
                "return JSON.stringify({url:location.href,title:document.title||'',blocked:blocked,blockReason:reason,links:as.length,items:out});"+
                "})()";
    }

    private static String detailScript() {
        return "(function(){"+
                "function n(t){if(!t)return 0;var m=String(t).replace(/\\u00a0/g,' ').match(/([0-9][0-9,]{2,})/);if(!m)return 0;var v=parseInt(m[1].replace(/,/g,''),10);return (v>=100&&v<=1000000000)?v:0;}"+
                "function add(arr,v){if(!v)return;for(var i=0;i<arr.length;i++)if(Math.abs(arr[i]-v)<1)return;arr.push(v);}"+
                "function vals(sels){var a=[];for(var i=0;i<sels.length;i++){var es=document.querySelectorAll(sels[i]);for(var j=0;j<es.length&&a.length<40;j++)add(a,n(es[j].getAttribute('content')||es[j].textContent));}return a;}"+
                "var bt=(document.body&&document.body.innerText?document.body.innerText:'').toLowerCase();var blocked=(bt.indexOf('access denied')>=0||bt.indexOf('captcha')>=0||bt.indexOf('자동입력')>=0||bt.indexOf('로봇이 아닙니다')>=0||bt.indexOf('비정상적인 접근')>=0);"+
                "var reason=bt.indexOf('captcha')>=0?'CAPTCHA':(bt.indexOf('access denied')>=0?'Access Denied':(bt.indexOf('비정상적인 접근')>=0?'비정상 접근 차단':''));"+
                "var cur=vals(['meta[itemprop=\"price\"]','meta[property=\"product:price:amount\"]','.total-price strong','.total-price','[class*=\"total-price\"] strong','[class*=\"sale-price\"]','[class*=\"sales-price\"]','[class*=\"discount-price\"]','.price-value','[class*=\"price-value\"]']);"+
                "var bas=vals(['.base-price','[class*=\"base-price\"]','[class*=\"original-price\"]','[class*=\"regular-price\"]','[class*=\"list-price\"]','del','s']);"+
                "try{var scripts=document.querySelectorAll('script[type=\"application/ld+json\"]');for(var k=0;k<scripts.length;k++){var o=JSON.parse(scripts[k].textContent||'{}');var arr=Array.isArray(o)?o:[o];for(var z=0;z<arr.length;z++){var q=arr[z]||{};if(q.offers){var of=Array.isArray(q.offers)?q.offers[0]:q.offers;if(of)add(cur,n(of.price));}}}}catch(e){}"+
                "var title='';var h=document.querySelector('h1');if(h)title=(h.textContent||'').trim();if(!title){var og=document.querySelector('meta[property=\"og:title\"]');if(og)title=og.getAttribute('content')||'';}if(!title)title=document.title||'';"+
                "return JSON.stringify({url:location.href,title:title,blocked:blocked,blockReason:reason,current:cur,base:bas});"+
                "})()";
    }

    public void destroy() {
        main.post(() -> {
            try { if (webView != null) { webView.stopLoading(); webView.destroy(); } } catch (Throwable ignored) {}
            webView = null;
        });
    }
}
