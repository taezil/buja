package com.dealflash.app;

import org.json.JSONObject;

public class DealItem {
    public String id;
    public String title;
    public String url;
    public String source;
    public String mode; // PRODUCT or FEED
    public double baselinePrice;
    public double lastPrice;
    public double minPrice;
    public int thresholdPct;
    public boolean enabled;
    public long lastCheckedAt;
    public String lastError;
    public String lastHitSignature;

    public static DealItem create(String title, String url, String mode, int thresholdPct) {
        DealItem d = new DealItem();
        d.id = Integer.toHexString(url.hashCode()) + "-" + System.currentTimeMillis();
        d.title = title == null || title.trim().isEmpty() ? shortName(url) : title.trim();
        d.url = url.trim();
        d.source = detectSource(url);
        d.mode = mode;
        d.thresholdPct = thresholdPct;
        d.enabled = true;
        d.baselinePrice = 0;
        d.lastPrice = 0;
        d.minPrice = 0;
        d.lastCheckedAt = 0;
        d.lastError = "아직 확인 전";
        d.lastHitSignature = "";
        return d;
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id); o.put("title", title); o.put("url", url); o.put("source", source);
            o.put("mode", mode); o.put("baselinePrice", baselinePrice); o.put("lastPrice", lastPrice);
            o.put("minPrice", minPrice); o.put("thresholdPct", thresholdPct); o.put("enabled", enabled);
            o.put("lastCheckedAt", lastCheckedAt); o.put("lastError", lastError); o.put("lastHitSignature", lastHitSignature);
        } catch (Exception ignored) {}
        return o;
    }

    public static DealItem fromJson(JSONObject o) {
        DealItem d = new DealItem();
        d.id = o.optString("id", ""); d.title = o.optString("title", "상품"); d.url = o.optString("url", "");
        d.source = o.optString("source", detectSource(d.url)); d.mode = o.optString("mode", "PRODUCT");
        d.baselinePrice = o.optDouble("baselinePrice", 0); d.lastPrice = o.optDouble("lastPrice", 0);
        d.minPrice = o.optDouble("minPrice", 0); d.thresholdPct = o.optInt("thresholdPct", 80);
        d.enabled = o.optBoolean("enabled", true); d.lastCheckedAt = o.optLong("lastCheckedAt", 0);
        d.lastError = o.optString("lastError", ""); d.lastHitSignature = o.optString("lastHitSignature", "");
        return d;
    }

    public static String detectSource(String url) {
        String u = url == null ? "" : url.toLowerCase();
        if (u.contains("coupang.com") || u.contains("link.coupang.com")) return "COUPANG";
        if (u.contains("toss.im") || u.contains("toss.shopping") || u.contains("shopping.toss")) return "TOSS";
        return "WEB";
    }

    private static String shortName(String url) {
        String s = detectSource(url);
        if ("COUPANG".equals(s)) return "쿠팡 감시";
        if ("TOSS".equals(s)) return "토스쇼핑 감시";
        return "웹 상품 감시";
    }
}
