package com.dealflash.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.List;

public class DealStore {
    private static final String PREF = "dealflash_store";
    private static final String KEY_DEALS = "deals";
    private static final String KEY_INTERVAL = "interval_sec";

    public static synchronized List<DealItem> load(Context c) {
        List<DealItem> out = new ArrayList<>();
        String raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_DEALS, "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) out.add(DealItem.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) {}
        return out;
    }

    public static synchronized void save(Context c, List<DealItem> deals) {
        JSONArray a = new JSONArray();
        for (DealItem d : deals) a.put(d.toJson());
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_DEALS, a.toString()).apply();
    }

    public static synchronized void upsert(Context c, DealItem item) {
        List<DealItem> deals = load(c);
        boolean found = false;
        for (int i = 0; i < deals.size(); i++) {
            if (deals.get(i).id.equals(item.id)) { deals.set(i, item); found = true; break; }
        }
        if (!found) deals.add(item);
        save(c, deals);
    }

    public static synchronized void delete(Context c, String id) {
        List<DealItem> deals = load(c);
        deals.removeIf(d -> d.id.equals(id));
        save(c, deals);
    }

    public static int getInterval(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt(KEY_INTERVAL, 10);
    }

    public static void setInterval(Context c, int sec) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt(KEY_INTERVAL, Math.max(10, sec)).apply();
    }
}
