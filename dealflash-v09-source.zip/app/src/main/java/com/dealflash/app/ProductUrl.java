package com.dealflash.app;

import java.net.URI;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Strict URL normalizer.  Never treats category/search/ad URLs as product URLs. */
public final class ProductUrl {
    private static final Pattern COUPANG = Pattern.compile(
            "(?i)^https?://(?:(?:www|m)\\.)?coupang\\.com/(?:vp|np|vm)/products/(\\d+)(?:[/?#].*)?$");
    private static final Pattern COUPANG_PATH = Pattern.compile(
            "(?i)^/(?:vp|np|vm)/products/(\\d+)(?:[/?#].*)?$");

    private ProductUrl() {}

    public static String resolve(String base, String raw) {
        if (raw == null) return null;
        String s = unescape(raw.trim());
        if (s.startsWith("//")) s = "https:" + s;
        try {
            if (!s.startsWith("http://") && !s.startsWith("https://")) {
                if (base == null || base.isEmpty()) return null;
                s = new URI(base).resolve(s).toString();
            }
            return s;
        } catch (Exception e) { return null; }
    }

    public static boolean isStrictCoupang(String url) {
        if (url == null) return false;
        return COUPANG.matcher(unescape(url)).matches();
    }

    public static String canonicalCoupang(String raw) {
        if (raw == null) return null;
        String s = unescape(raw.trim());
        if (s.startsWith("//")) s = "https:" + s;
        if (COUPANG_PATH.matcher(s).matches()) s = "https://www.coupang.com" + s;
        Matcher m = COUPANG.matcher(s);
        if (!m.matches()) return null;
        String id = m.group(1);
        String query = "";
        int q = s.indexOf('?');
        if (q >= 0) {
            int hash = s.indexOf('#', q);
            query = s.substring(q, hash >= 0 ? hash : s.length());
        }
        // Keep variant identifiers and other harmless query parameters so the exact option can open.
        return "https://www.coupang.com/vp/products/" + id + query;
    }

    public static String canonical(String source, String raw) {
        if ("COUPANG".equals(source)) return canonicalCoupang(raw);
        if (raw == null) return null;
        String s = unescape(raw.trim());
        if (s.startsWith("http://") || s.startsWith("https://")) return s;
        return null;
    }

    public static String key(String source, String url) {
        if ("COUPANG".equals(source)) {
            String c = canonicalCoupang(url);
            if (c == null) return "";
            Matcher m = COUPANG.matcher(c);
            if (m.matches()) {
                String productId = m.group(1);
                String itemId = queryParam(c, "itemId");
                String vendorItemId = queryParam(c, "vendorItemId");
                // Different options of one Coupang product can have very different prices.
                // Never compare those variants against each other as if they were the same item.
                if (!vendorItemId.isEmpty()) return "cp:" + productId + ":v:" + vendorItemId;
                if (!itemId.isEmpty()) return "cp:" + productId + ":i:" + itemId;
                return "cp:" + productId;
            }
        }
        if (url == null) return "";
        int q = url.indexOf('?');
        String u = q > 0 ? url.substring(0, q) : url;
        return Integer.toHexString(u.hashCode()) + ":" + u.length();
    }

    private static String queryParam(String url, String name) {
        if (url == null) return "";
        int q = url.indexOf('?');
        if (q < 0 || q + 1 >= url.length()) return "";
        int end = url.indexOf('#', q);
        String query = url.substring(q + 1, end >= 0 ? end : url.length());
        String[] parts = query.split("&");
        for (String part : parts) {
            int eq = part.indexOf('=');
            String k = eq >= 0 ? part.substring(0, eq) : part;
            if (name.equalsIgnoreCase(k)) {
                String v = eq >= 0 ? part.substring(eq + 1) : "";
                return v.replaceAll("[^0-9A-Za-z_-]", "");
            }
        }
        return "";
    }

    private static String unescape(String s) {
        return s.replace("\\u002F", "/").replace("\\/", "/")
                .replace("&amp;", "&").replace("&#38;", "&");
    }
}
