package com.dealflash.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public class HotDealStore {
    private static final String PREF="dealflash_hot_v6", KEY="hot";
    public static class Hot {
        public String key,title,url,source,imageUrl="";
        public double current,reference,marketPrice;
        public int dropPct;
        public long foundAt,lastVerifiedAt;
        public boolean verified;
        JSONObject json(){JSONObject o=new JSONObject();try{o.put("key",key);o.put("title",title);o.put("url",url);o.put("source",source);o.put("imageUrl",imageUrl);o.put("current",current);o.put("reference",reference);o.put("marketPrice",marketPrice);o.put("dropPct",dropPct);o.put("foundAt",foundAt);o.put("lastVerifiedAt",lastVerifiedAt);o.put("verified",verified);}catch(Exception ignored){}return o;}
        static Hot from(JSONObject o){Hot h=new Hot();h.key=o.optString("key");h.title=o.optString("title","상품");h.url=o.optString("url");h.source=o.optString("source","COUPANG");h.imageUrl=o.optString("imageUrl","");h.current=o.optDouble("current");h.reference=o.optDouble("reference");h.marketPrice=o.optDouble("marketPrice");h.dropPct=o.optInt("dropPct");h.foundAt=o.optLong("foundAt");h.lastVerifiedAt=o.optLong("lastVerifiedAt");h.verified=o.optBoolean("verified");return h;}
    }
    public static synchronized List<Hot> all(Context c){ArrayList<Hot> out=new ArrayList<>();try{JSONArray a=new JSONArray(c.getSharedPreferences(PREF,0).getString(KEY,"[]"));for(int i=0;i<a.length();i++)out.add(Hot.from(a.getJSONObject(i)));}catch(Exception ignored){}out.sort((a,b)->Long.compare(b.foundAt,a.foundAt));return out;}
    public static synchronized List<Hot> recent(Context c){long cut=System.currentTimeMillis()-24L*60*60*1000;ArrayList<Hot> out=new ArrayList<>();for(Hot h:all(c))if(h.foundAt>=cut)out.add(h);return out;}
    public static synchronized void put(Context c,String key,String title,String url,String source,double current,double reference,int pct){List<Hot> a=all(c);Hot found=null;for(Hot h:a)if(h.key.equals(key)){found=h;break;}long now=System.currentTimeMillis();if(found==null){found=new Hot();found.key=key;found.foundAt=now;a.add(found);}found.title=title;found.url=url;found.source=source;found.current=current;found.reference=reference;found.dropPct=pct;found.lastVerifiedAt=now;found.verified=true;save(c,a);}
    private static void save(Context c,List<Hot> list){JSONArray a=new JSONArray();long keep=System.currentTimeMillis()-90L*24*60*60*1000;int n=0;for(Hot h:list){if(h.foundAt<keep||n>=1000)continue;a.put(h.json());n++;}c.getSharedPreferences(PREF,0).edit().putString(KEY,a.toString()).apply();}
    public static void clear(Context c){c.getSharedPreferences(PREF,0).edit().clear().apply();}
}
