package com.dealflash.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class HistoryStore {
    private static final String PREF = "dealflash_history_v6";
    private static final String KEY = "items";
    private static final int MAX = 5000;

    public static class H {
        public String key, title, url, source;
        public double reference, last, low;
        public long firstSeen, lastSeen;
        public String lastAlertSig = "";
    }

    public static synchronized Map<String,H> load(Context c) {
        HashMap<String,H> map = new HashMap<>();
        String raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i=0;i<a.length();i++) {
                JSONObject o=a.getJSONObject(i); H h=new H();
                h.key=o.optString("key"); h.title=o.optString("title"); h.url=o.optString("url"); h.source=o.optString("source");
                h.reference=o.optDouble("reference"); h.last=o.optDouble("last"); h.low=o.optDouble("low");
                h.firstSeen=o.optLong("firstSeen"); h.lastSeen=o.optLong("lastSeen"); h.lastAlertSig=o.optString("lastAlertSig","");
                if (!h.key.isEmpty()) map.put(h.key,h);
            }
        } catch(Exception ignored){}
        return map;
    }

    public static synchronized void save(Context c, Map<String,H> map) {
        // Keep the most recently seen entries if the cache becomes large.
        java.util.ArrayList<H> list=new java.util.ArrayList<>(map.values());
        list.sort((a,b)->Long.compare(b.lastSeen,a.lastSeen));
        JSONArray a=new JSONArray();
        int n=Math.min(MAX,list.size());
        for(int i=0;i<n;i++) {
            H h=list.get(i); JSONObject o=new JSONObject();
            try {
                o.put("key",h.key);o.put("title",h.title);o.put("url",h.url);o.put("source",h.source);
                o.put("reference",h.reference);o.put("last",h.last);o.put("low",h.low);
                o.put("firstSeen",h.firstSeen);o.put("lastSeen",h.lastSeen);o.put("lastAlertSig",h.lastAlertSig);
                a.put(o);
            } catch(Exception ignored){}
        }
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(KEY,a.toString()).apply();
    }

    public static synchronized void clear(Context c) {
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }
}
