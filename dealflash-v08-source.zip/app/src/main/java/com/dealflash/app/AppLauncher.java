package com.dealflash.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.widget.Toast;

public class AppLauncher {
    public static boolean isInstalled(Context c, String pkg) {
        try { c.getPackageManager().getPackageInfo(pkg, 0); return true; }
        catch (Exception e) { return false; }
    }

    /** Opens a validated product link. Shopping app is attempted only when Android says it can handle it. */
    public static void openProduct(Context c, String source, String rawUrl) {
        String url = ProductUrl.canonical(source, rawUrl);
        if (url == null) {
            Toast.makeText(c, "상품 링크가 올바르지 않아 열지 않았어.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        String pkg = null;
        if ("COUPANG".equals(source)) pkg = "com.coupang.mobile";
        else if ("TOSS".equals(source)) pkg = "viva.republica.toss";

        if (pkg != null && isInstalled(c, pkg)) {
            // Prefer the installed shopping app. Do not pre-resolve: some app links are
            // handled dynamically and resolveActivity can incorrectly return null.
            appIntent.setPackage(pkg);
            try { c.startActivity(appIntent); return; } catch (Exception ignored) {}
        }

        // Guaranteed web fallback: do not pin a package.
        try {
            Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            c.startActivity(web);
        } catch (Exception e) {
            Toast.makeText(c, "상품 페이지를 열 수 없어. 링크: " + url, Toast.LENGTH_LONG).show();
        }
    }

    public static void openUrl(Context c, String url) {
        String source = DealItem.detectSource(url);
        String canonical = ProductUrl.canonical(source, url);
        if (canonical != null && ("COUPANG".equals(source) || "TOSS".equals(source))) {
            openProduct(c, source, canonical); return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i);
        } catch(Exception e) { Toast.makeText(c, "링크를 열 수 없어.", Toast.LENGTH_SHORT).show(); }
    }

    public static void warmCoupang(Context c) {
        if (isInstalled(c, "com.coupang.mobile")) {
            Intent i = c.getPackageManager().getLaunchIntentForPackage("com.coupang.mobile");
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); return; }
        }
        openUrl(c, "https://www.coupang.com/");
    }

    public static void warmToss(Context c) {
        if (isInstalled(c, "viva.republica.toss")) {
            Intent i = c.getPackageManager().getLaunchIntentForPackage("viva.republica.toss");
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); return; }
        }
        openUrl(c, "https://toss.im/");
    }
}
