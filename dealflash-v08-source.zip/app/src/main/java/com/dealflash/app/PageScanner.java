package com.dealflash.app;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Search/category parser. V0.3 intentionally prefers false negatives over false alerts:
 * - Coupang entries MUST carry a real /vp/products/{id} URL.
 * - A visible "80%" badge is never used by itself as a price-drop signal.
 * - Current/original prices are accepted only from price-specific fields/classes.
 */
public class PageScanner {
    public static class Listing {
        public String key;
        public String title;
        public String url;
        public double price;
        public double basePrice;
        /** informational only; never triggers an alert on its own */
        public int declaredDiscountPct;
    }

    private static final Pattern COUPANG_CARD = Pattern.compile(
            "(?is)<li[^>]*class=[\\\"'][^\\\"']*(?:search-product|baby-product|product-list|product-unit)[^\\\"']*[\\\"'][^>]*>(.*?)</li>");
    private static final Pattern COUPANG_PRODUCT_ANCHOR = Pattern.compile(
            "(?is)<a[^>]+href=[\\\"']([^\\\"']*/(?:vp|np)/products/\\d+[^\\\"']*)[\\\"'][^>]*>(.{0,9000}?)</a>");
    private static final Pattern PRODUCT_LINK = Pattern.compile(
            "(?is)href=[\\\"']([^\\\"']*/(?:vp|np)/products/\\d+[^\\\"']*)[\\\"']");
    private static final Pattern NAME = Pattern.compile(
            "(?is)<(?:div|span)[^>]*class=[\\\"'][^\\\"']*(?:name|product-name)[^\\\"']*[\\\"'][^>]*>(.*?)</(?:div|span)>");

    private static final Pattern[] CURRENT_PATTERNS = new Pattern[] {
            Pattern.compile("(?is)class=[\\\"'][^\\\"']*(?:price-value|sale-price|sales-price|final-price|discount-price)[^\\\"']*[\\\"'][^>]*>\\s*(?:<[^>]+>\\s*)*([0-9][0-9,]*)"),
            Pattern.compile("(?is)\\\"(?:salePrice|salesPrice|finalPrice|sellingPrice|discountPrice)\\\"\\s*:\\s*\\\"?([0-9][0-9,]*)")
    };
    private static final Pattern[] BASE_PATTERNS = new Pattern[] {
            Pattern.compile("(?is)class=[\\\"'][^\\\"']*(?:base-price|original-price|regular-price|list-price)[^\\\"']*[\\\"'][^>]*>\\s*(?:<[^>]+>\\s*)*([0-9][0-9,]*)"),
            Pattern.compile("(?is)\\\"(?:basePrice|originalPrice|regularPrice|listPrice|retailPrice)\\\"\\s*:\\s*\\\"?([0-9][0-9,]*)")
    };
    private static final Pattern DECLARED_DISCOUNT = Pattern.compile(
            "(?is)(?:class=[\\\"'][^\\\"']*(?:discount-percentage|discount-rate|discount)[^\\\"']*[\\\"'][^>]*>|\\\"(?:discountRate|discountPercent)\\\"\\s*:\\s*\\\"?)([0-9]{1,3})\\s*%?");

    // Used only for non-Coupang public/share pages. Still requires two explicit won prices to infer a drop.
    private static final Pattern GENERIC_ANCHOR = Pattern.compile(
            "(?is)<a[^>]+href=[\\\"']([^\\\"']+)[\\\"'][^>]*>(.{0,4000}?)</a>");
    private static final Pattern WON_PRICE = Pattern.compile("([0-9][0-9,]{2,})\\s*원");

    public static List<Listing> scan(String html, String baseUrl, String source) {
        ArrayList<Listing> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        if (html == null || html.isEmpty()) return out;

        if ("COUPANG".equals(source)) {
            Matcher bm = COUPANG_CARD.matcher(html);
            while (bm.find() && out.size() < 220) {
                Listing x = parseCoupangBlock(bm.group(1), baseUrl);
                if (validCoupang(x) && seen.add(x.key)) out.add(x);
            }

            // Some Coupang layouts do not wrap cards in <li>. The fallback still requires a strict
            // product URL and explicit price fields; generic percentage text is ignored.
            Matcher am = COUPANG_PRODUCT_ANCHOR.matcher(html);
            while (am.find() && out.size() < 260) {
                Listing x = parseCoupangAnchor(am.group(1), am.group(2), baseUrl);
                if (validCoupang(x) && seen.add(x.key)) out.add(x);
            }
            return out;
        }

        // Toss/public pages: conservative fallback. No alert can happen merely because "80%" appears.
        Matcher am = GENERIC_ANCHOR.matcher(html);
        while (am.find() && out.size() < 160) {
            String href = ProductUrl.resolve(baseUrl, am.group(1));
            String block = am.group(2);
            if (href == null || href.length() < 8) continue;
            if ("TOSS".equals(source) && !(href.contains("toss.im") || href.contains("toss"))) continue;

            List<Double> prices = new ArrayList<>();
            Matcher pm = WON_PRICE.matcher(strip(block));
            while (pm.find() && prices.size() < 3) {
                double v = price(pm.group(1));
                if (validPrice(v)) prices.add(v);
            }
            if (prices.isEmpty()) continue;
            Listing x = new Listing();
            x.url = href;
            x.key = ProductUrl.key(source, href);
            x.title = cleanTitle(strip(block));
            // Only infer original/current when exactly ordered as larger -> smaller.
            if (prices.size() >= 2 && prices.get(0) > prices.get(1)) {
                x.basePrice = prices.get(0); x.price = prices.get(1);
            } else x.price = prices.get(0);
            if (validGeneric(x) && seen.add(x.key)) out.add(x);
        }
        return out;
    }

    private static Listing parseCoupangBlock(String block, String baseUrl) {
        Matcher lm = PRODUCT_LINK.matcher(block);
        if (!lm.find()) return null;
        return buildCoupang(lm.group(1), block, baseUrl);
    }

    private static Listing parseCoupangAnchor(String href, String block, String baseUrl) {
        return buildCoupang(href, block, baseUrl);
    }

    private static Listing buildCoupang(String href, String block, String baseUrl) {
        String resolved = ProductUrl.resolve(baseUrl, href);
        String canonical = ProductUrl.canonicalCoupang(resolved);
        if (canonical == null) return null;
        Listing x = new Listing();
        x.url = canonical;
        x.key = ProductUrl.key("COUPANG", canonical);

        Matcher nm = NAME.matcher(block);
        x.title = nm.find() ? cleanTitle(strip(nm.group(1))) : cleanTitle(strip(block));
        x.price = firstPrice(block, CURRENT_PATTERNS);
        x.basePrice = firstPrice(block, BASE_PATTERNS);
        Matcher dm = DECLARED_DISCOUNT.matcher(block);
        if (dm.find()) x.declaredDiscountPct = safeInt(dm.group(1));

        // Never manufacture a base price from the percent badge. It is only informational.
        if (!validPair(x.basePrice, x.price)) x.basePrice = 0;
        return x;
    }

    private static double firstPrice(String s, Pattern[] ps) {
        for (Pattern p : ps) {
            Matcher m = p.matcher(s);
            while (m.find()) {
                double v = price(m.group(1));
                if (validPrice(v)) return v;
            }
        }
        return 0;
    }

    public static boolean validPair(double base, double current) {
        if (!validPrice(base) || !validPrice(current) || base <= current) return false;
        double pct = (1.0 - current / base) * 100.0;
        return base >= 5000 && pct >= 1.0 && pct <= 95.0;
    }

    private static boolean validCoupang(Listing x) {
        return x != null && ProductUrl.isStrictCoupang(x.url) && !x.key.isEmpty()
                && validPrice(x.price) && x.title != null && !x.title.isEmpty();
    }
    private static boolean validGeneric(Listing x) {
        return x != null && x.url != null && !x.key.isEmpty() && validPrice(x.price);
    }
    private static boolean validPrice(double v) { return v >= 100 && v <= 1_000_000_000L; }
    private static double price(String s) { try { return Double.parseDouble(s.replace(",", "").trim()); } catch(Exception e){ return 0; } }
    private static int safeInt(String s) { try { return Integer.parseInt(s); } catch(Exception e){ return 0; } }
    private static String strip(String s) {
        if (s == null) return "";
        return s.replaceAll("(?is)<script.*?</script>", " ")
                .replaceAll("(?is)<style.*?</style>", " ")
                .replaceAll("(?is)<[^>]+>", " ")
                .replace("&nbsp;", " ").replace("&amp;", "&")
                .replaceAll("\\s+", " ").trim();
    }
    private static String cleanTitle(String s) {
        if (s == null || s.trim().isEmpty()) return "쿠팡 상품";
        s = s.replaceAll("\\s+", " ").trim();
        return s.length() > 100 ? s.substring(0, 100) : s;
    }
}
