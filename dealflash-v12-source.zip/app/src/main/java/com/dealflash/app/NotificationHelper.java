package com.dealflash.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;

public class NotificationHelper {
    public static final String CH_MONITOR="dealflash_monitor_v12";
    public static final String CH_ALERT="dealflash_alert_v12";

    public static void ensureChannels(Context c){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=c.getSystemService(NotificationManager.class);
            NotificationChannel monitor=new NotificationChannel(CH_MONITOR,"폴센트 급락 감시",NotificationManager.IMPORTANCE_LOW);
            monitor.setDescription("폴센트 추천페이지 감시 상태");
            NotificationChannel alert=new NotificationChannel(CH_ALERT,"급락 즉시 알림",NotificationManager.IMPORTANCE_HIGH);
            alert.setDescription("폴센트 추천페이지에서 포착한 급락 후보");
            alert.enableVibration(true);alert.enableLights(true);alert.setLightColor(Color.RED);
            nm.createNotificationChannel(monitor);nm.createNotificationChannel(alert);
        }
    }

    public static Notification monitorNotification(Context c,String text){
        Intent i=new Intent(c,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,1,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CH_MONITOR):new Notification.Builder(c);
        return b.setContentTitle("급락포착 V1.2 · 폴센트 감시 중").setContentText(text)
                .setSmallIcon(android.R.drawable.ic_popup_sync).setOngoing(true).setContentIntent(pi).build();
    }

    public static void alert(Context c,DealItem d,String title,String body,String openUrl){alertAuto(c,d.source,d.id,title,body,openUrl);}

    public static void alertAuto(Context c,String source,String key,String title,String body,String openUrl){
        String safe=ProductUrl.canonical(source,openUrl);
        if(safe==null) return; // Never create a notification that cannot map to a verified product URL.
        ensureChannels(c);
        Intent i=new Intent(c,MainActivity.class);
        i.putExtra("hotKey",key);i.putExtra("source",source);i.putExtra("url",safe);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int request=Math.abs((key+safe).hashCode());
        PendingIntent pi=PendingIntent.getActivity(c,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CH_ALERT):new Notification.Builder(c);
        Notification n=b.setContentTitle(title).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body))
                .setSmallIcon(android.R.drawable.stat_sys_warning).setAutoCancel(true).setContentIntent(pi)
                .addAction(android.R.drawable.ic_menu_view,"상품 열기",pi)
                .setPriority(Notification.PRIORITY_MAX).setDefaults(Notification.DEFAULT_ALL).build();
        c.getSystemService(NotificationManager.class).notify(Math.abs(("verified"+key+safe).hashCode()),n);
    }

    /** This tests the notification channel only and deliberately does not masquerade as a real product alert. */
    public static void test(Context c){
        ensureChannels(c);
        Intent i=new Intent(c,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,991,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CH_ALERT):new Notification.Builder(c);
        Notification n=b.setContentTitle("🔔 알림 기능 테스트")
                .setContentText("이건 상품 급락 알림이 아니야. 누르면 급락포착 앱으로 돌아와.")
                .setSmallIcon(android.R.drawable.stat_notify_more).setAutoCancel(true).setContentIntent(pi).build();
        c.getSystemService(NotificationManager.class).notify(991,n);
    }
}
