package com.dealflash.app;

import android.content.Context;
import android.content.SharedPreferences;

public class ScannerPrefs {
    private static final String PREF="dealflash_auto_v7";
    private static SharedPreferences p(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    public static boolean enabled(Context c){return p(c).getBoolean("enabled",true);}
    public static void enabled(Context c,boolean v){p(c).edit().putBoolean("enabled",v).apply();}
    public static boolean coupang(Context c){return p(c).getBoolean("coupang",true);}
    public static void coupang(Context c,boolean v){p(c).edit().putBoolean("coupang",v).apply();}
    public static boolean toss(Context c){return p(c).getBoolean("toss",false);}
    public static void toss(Context c,boolean v){p(c).edit().putBoolean("toss",v).apply();}
    public static int threshold(Context c){return p(c).getInt("threshold",50);}
    public static void threshold(Context c,int v){p(c).edit().putInt("threshold",Math.max(0,Math.min(100,(v/10)*10))).apply();}
    public static int interval(Context c){return p(c).getInt("interval",10);}
    public static int minSaving(Context c){return p(c).getInt("minSaving",0);}
    public static void minSaving(Context c,int v){p(c).edit().putInt("minSaving",Math.max(0,v)).apply();}
    public static boolean errorCandidate(Context c){return p(c).getBoolean("errorCandidate",true);}
    public static void errorCandidate(Context c,boolean v){p(c).edit().putBoolean("errorCandidate",v).apply();}
    public static void interval(Context c,int v){p(c).edit().putInt("interval",Math.max(10,Math.min(180,v))).apply();}
    public static int cursor(Context c){return p(c).getInt("cursor",0);}
    public static void cursor(Context c,int v){p(c).edit().putInt("cursor",Math.max(0,v)).apply();}
    public static long lastCheck(Context c){return p(c).getLong("lastCheck",0);}
    public static long pages(Context c){return p(c).getLong("pages",0);}
    public static long products(Context c){return p(c).getLong("products",0);}
    /** verified notifications only */
    public static long hits(Context c){return p(c).getLong("hits",0);}
    /** suspicious cards rejected by detail-page verification */
    public static long rejected(Context c){return p(c).getLong("rejected",0);}
    public static long errors(Context c){return p(c).getLong("errors",0);}
    public static long success(Context c){return p(c).getLong("success",0);}
    public static long cooldownSkips(Context c){return p(c).getLong("cooldownSkips",0);}
    public static long blocked(Context c){return p(c).getLong("blocked",0);}
    public static long timeouts(Context c){return p(c).getLong("timeouts",0);}
    public static long empty(Context c){return p(c).getLong("empty",0);}
    public static String current(Context c){return p(c).getString("current","");}
    public static void stats(Context c,long last,long pages,long products,long hits,long rejected,long errors,long success,long cooldownSkips,long blocked,long timeouts,long empty,String current){
        p(c).edit().putLong("lastCheck",last).putLong("pages",pages).putLong("products",products)
                .putLong("hits",hits).putLong("rejected",rejected).putLong("errors",errors)
                .putLong("success",success).putLong("cooldownSkips",cooldownSkips).putLong("blocked",blocked).putLong("timeouts",timeouts).putLong("empty",empty)
                .putString("current",current==null?"":current).apply();
    }
    public static void resetStats(Context c){
        p(c).edit().putLong("lastCheck",0).putLong("pages",0).putLong("products",0).putLong("hits",0)
                .putLong("rejected",0).putLong("errors",0).putLong("success",0).putLong("cooldownSkips",0).putLong("blocked",0).putLong("timeouts",0).putLong("empty",0).putString("current","").apply();
    }
}
